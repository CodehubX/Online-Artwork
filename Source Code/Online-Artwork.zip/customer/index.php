<?php
    header("Location: welcome.php");
?>